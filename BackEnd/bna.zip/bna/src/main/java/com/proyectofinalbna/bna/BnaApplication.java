package com.proyectofinalbna.bna;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BnaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BnaApplication.class, args);
	}

}
